<?php

$app = new \OCA\Files_external_ftp\AppInfo\Application();

