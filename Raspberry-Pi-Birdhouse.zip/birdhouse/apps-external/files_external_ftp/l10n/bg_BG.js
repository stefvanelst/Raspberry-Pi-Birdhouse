OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Потребителско име",
    "Password" : "Парола",
    "Host" : "Host",
    "Root" : "Root",
    "Port" : "Порт",
    "Secure ftps://" : "Сигурен ftps://"
},
"nplurals=2; plural=(n != 1);");
