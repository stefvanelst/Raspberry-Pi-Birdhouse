OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Uporabniško ime",
    "Password" : "Geslo",
    "Host" : "Gostitelj",
    "Root" : "Koren",
    "Port" : "Vrata",
    "Secure ftps://" : "Varni način ftps://"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
