OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Uživatelské jméno",
    "Password" : "Heslo",
    "Host" : "Počítač",
    "Root" : "Kořen",
    "Port" : "Port",
    "Secure ftps://" : "Zabezpečené ftps://"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
