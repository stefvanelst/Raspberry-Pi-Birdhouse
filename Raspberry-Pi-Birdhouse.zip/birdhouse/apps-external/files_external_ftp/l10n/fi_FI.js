OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Käyttäjätunnus",
    "Password" : "Salasana",
    "Host" : "Isäntä",
    "Port" : "Portti",
    "Secure ftps://" : "Salattu ftps://"
},
"nplurals=2; plural=(n != 1);");
