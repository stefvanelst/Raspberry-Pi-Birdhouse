OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Emër përdoruesi",
    "Password" : "Fjalëkalim",
    "Host" : "Strehë",
    "Root" : "Rrënjë",
    "Port" : "Portë",
    "Secure ftps://" : "ftps:// e sigurt"
},
"nplurals=2; plural=(n != 1);");
