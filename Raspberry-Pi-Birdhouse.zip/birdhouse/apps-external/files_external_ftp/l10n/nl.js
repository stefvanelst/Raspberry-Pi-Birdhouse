OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Gebruikersnaam",
    "Password" : "Wachtwoord",
    "Host" : "Server",
    "Root" : "Root",
    "Port" : "Poort",
    "Secure ftps://" : "Secure ftps://"
},
"nplurals=2; plural=(n != 1);");
