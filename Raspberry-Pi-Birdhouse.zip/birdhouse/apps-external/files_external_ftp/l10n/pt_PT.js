OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Nome de utilizador",
    "Password" : "Palavra-passe",
    "Host" : "Anfitrião",
    "Root" : "Root",
    "Port" : "Porta",
    "Secure ftps://" : "ftps:// Seguro"
},
"nplurals=2; plural=(n != 1);");
