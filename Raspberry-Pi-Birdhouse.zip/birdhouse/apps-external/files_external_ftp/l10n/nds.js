OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Benutzername",
    "Password" : "Passwort",
    "Host" : "Host",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Sicheres fpts://"
},
"nplurals=2; plural=(n != 1);");
