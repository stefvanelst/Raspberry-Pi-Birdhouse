OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Nama pengguna",
    "Password" : "Kata Sandi",
    "Host" : "Host",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Secure ftps://"
},
"nplurals=1; plural=0;");
