OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Nom d'utilisateur",
    "Password" : "Mot de passe",
    "Host" : "Hôte",
    "Root" : "Racine",
    "Port" : "Port",
    "Secure ftps://" : "Sécurisation ftps://"
},
"nplurals=2; plural=(n > 1);");
