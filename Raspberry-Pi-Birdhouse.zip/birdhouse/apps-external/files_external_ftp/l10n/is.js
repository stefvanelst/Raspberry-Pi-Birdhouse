OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Notandanafn",
    "Password" : "Lykilorð",
    "Host" : "Hýsilvél",
    "Root" : "Rót (root)",
    "Port" : "Gátt",
    "Secure ftps://" : "Öruggt ftps://"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
