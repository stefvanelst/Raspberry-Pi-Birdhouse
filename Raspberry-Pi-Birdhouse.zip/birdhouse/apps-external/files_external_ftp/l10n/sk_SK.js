OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Používateľské meno",
    "Password" : "Heslo",
    "Host" : "Hostiteľ",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Zabezpečené ftps://"
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
