OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Korisničko ime",
    "Password" : "Lozinka",
    "Host" : "Glavno računalo",
    "Root" : "Korijen",
    "Port" : "Priključak",
    "Secure ftps://" : "Sigurni ftps://"
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
