OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Erabiltzaile izena",
    "Password" : "Pasahitza",
    "Host" : "Ostalaria",
    "Root" : "Erroa",
    "Port" : "Portua",
    "Secure ftps://" : "ftps:// segurua"
},
"nplurals=2; plural=(n != 1);");
