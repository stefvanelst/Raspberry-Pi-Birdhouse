OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Nome do Usuário",
    "Password" : "Senha",
    "Host" : "Host",
    "Root" : "Raiz",
    "Port" : "Porta",
    "Secure ftps://" : "Seguro ftps://"
},
"nplurals=2; plural=(n > 1);");
