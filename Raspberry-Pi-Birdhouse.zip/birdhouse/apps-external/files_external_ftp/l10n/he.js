OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "שם משתמש",
    "Password" : "סיסמא",
    "Host" : "מארח",
    "Root" : "נתיב ראשי",
    "Port" : "שער",
    "Secure ftps://" : "פרוטוקול מאובטח ftps://"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
