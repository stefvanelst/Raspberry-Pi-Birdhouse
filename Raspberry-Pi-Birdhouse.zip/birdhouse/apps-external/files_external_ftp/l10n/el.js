OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Όνομα χρήστη",
    "Password" : "Κωδικός πρόσβασης",
    "Host" : "Διακομιστής",
    "Root" : "Root",
    "Port" : "Θύρα",
    "Secure ftps://" : "Ασφαλής ftps://"
},
"nplurals=2; plural=(n != 1);");
