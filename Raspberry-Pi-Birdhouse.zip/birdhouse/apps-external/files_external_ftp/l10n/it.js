OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Nome utente",
    "Password" : "Password",
    "Host" : "Host",
    "Root" : "Radice",
    "Port" : "Porta",
    "Secure ftps://" : "Sicuro ftps://"
},
"nplurals=2; plural=(n != 1);");
