OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Uzantonomo",
    "Password" : "Pasvorto",
    "Host" : "Gastigo",
    "Root" : "Radiko",
    "Port" : "Pordo",
    "Secure ftps://" : "Sekura ftps://"
},
"nplurals=2; plural=(n != 1);");
