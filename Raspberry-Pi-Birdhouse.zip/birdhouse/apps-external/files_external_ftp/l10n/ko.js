OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP(Fly)",
    "Username" : "사용자 이름",
    "Password" : "암호",
    "Host" : "호스트",
    "Root" : "루트",
    "Port" : "포트",
    "Secure ftps://" : "보안 ftps://"
},
"nplurals=1; plural=0;");
