OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Brukarnamn",
    "Password" : "Passord",
    "Host" : "Tenar",
    "Root" : "Rot",
    "Port" : "Port",
    "Secure ftps://" : "Sikker ftp med ftps://"
},
"nplurals=2; plural=(n != 1);");
