OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Kasutajanimi",
    "Password" : "Parool",
    "Host" : "Host",
    "Root" : "Juur",
    "Port" : "Port",
    "Secure ftps://" : "Turvaline ftps://"
},
"nplurals=2; plural=(n != 1);");
