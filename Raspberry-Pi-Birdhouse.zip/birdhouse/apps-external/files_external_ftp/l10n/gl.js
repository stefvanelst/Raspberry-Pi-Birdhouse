OC.L10N.register(
    "files_external_ftp",
    {
    "Username" : "Nome de usuario",
    "Password" : "Contrasinal",
    "Host" : "Máquina",
    "Root" : "Root (raíz)",
    "Port" : "Porto",
    "Secure ftps://" : "ftps:// seguro"
},
"nplurals=2; plural=(n != 1);");
