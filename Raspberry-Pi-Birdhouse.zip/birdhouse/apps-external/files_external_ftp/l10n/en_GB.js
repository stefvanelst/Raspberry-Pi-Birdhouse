OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Username",
    "Password" : "Password",
    "Host" : "Host",
    "Root" : "Root",
    "Port" : "Port",
    "Secure ftps://" : "Secure ftps://"
},
"nplurals=2; plural=(n != 1);");
