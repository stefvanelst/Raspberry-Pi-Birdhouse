OC.L10N.register(
    "files_external_ftp",
    {
    "FTP (Fly)" : "FTP (Fly)",
    "Username" : "Identificant",
    "Password" : "Senhal",
    "Host" : "Òste",
    "Root" : "Raiç",
    "Port" : "Pòrt",
    "Secure ftps://" : "Securizacion ftps://"
},
"nplurals=2; plural=(n > 1);");
