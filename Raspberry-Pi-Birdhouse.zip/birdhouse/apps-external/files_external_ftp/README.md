# files_external_ftp
Flysystem based ftp backend for ownCloud

Requires ownCloud 10.0 or later

[![Build Status](https://travis-ci.org/owncloud/files_external_ftp.svg?branch=master)](https://travis-ci.org/owncloud/files_external_ftp)
[![Code Coverage](https://scrutinizer-ci.com/g/owncloud/files_external_ftp/badges/coverage.png?b=master)](https://scrutinizer-ci.com/g/owncloud/files_external_ftp/?branch=master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/owncloud/files_external_ftp/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/owncloud/files_external_ftp/?branch=master)
